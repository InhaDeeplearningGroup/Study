#include <iostream>
//#include "CircleArrayQueue.h"
//#include "DynArrayQueue.h"
#include "ArrayStack.h"

int main() {
//    CircleArrayQueueMain();
//    DynArrayQueueMain();
//    ArrayStackMain();
    QueueStackMain();

    return 0;
}